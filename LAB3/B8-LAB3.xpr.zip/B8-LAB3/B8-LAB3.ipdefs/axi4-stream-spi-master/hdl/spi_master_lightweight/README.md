# SPI Master Lightweight

Taken from [OpenCores](https://opencores.org/projects/spi_master_lightweight).
